package com.example.myhealthnew;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class AddMealClient extends AppCompatActivity {
    private DatabaseReference referenceFood;
    private DatabaseReference referenceClient;
    private String clientID;
    private FirebaseUser client;
    FoodItem current_food;

    //Category
    String[] categoryItems = {"Carbohydrates", "Proteins", "Vegetables", "Fruits",  "Other"};
    AutoCompleteTextView idCategory;
    ArrayAdapter<String> adapterItemsCategory;
    String category;
    ArrayList<String> names_temp = new ArrayList<String>();


    //Foods
    private String[] namesOfFood;
    private HashMap<String, FoodItem> foodsMap;
    AutoCompleteTextView idFood;
    ArrayAdapter<String> adapterItemsFood;
    String foodName;
    private String[] temp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_meal_client);

        referenceFood = FirebaseDatabase.getInstance().getReference("Foods");
        client = FirebaseAuth.getInstance().getCurrentUser();
        referenceClient = FirebaseDatabase.getInstance().getReference("Clients");
        clientID = client.getUid();
        foodsMap = new HashMap<>();
        temp = new String[2];

        //Category
        idCategory = findViewById(R.id.txtCategory);
        adapterItemsCategory = new ArrayAdapter<String>(this,R.layout.list_items, categoryItems);
        idCategory.setAdapter(adapterItemsCategory);

        idCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
            }
        });

//        names_temp = new ArrayList<String>();
        Toast.makeText(getApplicationContext(), "category: "+category, Toast.LENGTH_LONG).show();
    }


    int i;
    public void OkCategory(View view){
        Toast.makeText(getApplicationContext(), "OK click: ", Toast.LENGTH_SHORT).show();

        // get all food in this category
        referenceFood.child(category).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Iterator<DataSnapshot> it = snapshot.getChildren().iterator();
                i=0;
                Toast.makeText(getApplicationContext(), "before while", Toast.LENGTH_SHORT).show();

                while(it.hasNext()){
                    Toast.makeText(getApplicationContext(), "inside while", Toast.LENGTH_SHORT).show();
                    DataSnapshot food_temp = it.next();
                    String name = food_temp.child("name").getValue().toString().trim();
                    String calories = food_temp.child("calories").getValue().toString().trim();
                    String unit = food_temp.child("unit").getValue().toString().trim();
                    String sodium = food_temp.child("sodium").getValue().toString().trim();
                    String cholesterol = food_temp.child("cholesterol").getValue().toString().trim();
                    String sugars = food_temp.child("sugars").getValue().toString().trim();
                    String fats = food_temp.child("fats").getValue().toString().trim();
                    FoodItem current_food = new FoodItem(name, calories, unit, sodium,
                            cholesterol, sugars, fats);
                    names_temp.add(name);
                    foodsMap.put(name, current_food);

                    temp[i] = name;
                    ++i;
                    Toast.makeText(getApplicationContext(), i+" "+name, Toast.LENGTH_SHORT).show();
                }



            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

//        namesOfFood = names_temp.toArray(new String[names_temp.size()]);
//        for (int j=0; j<100; ++j){
//            if (temp[j] == null){
//                temp[j]
//            }
//        }
//        namesOfFood = new String[i];
//        for (int j=0; j<i; ++j){
//            namesOfFood[j] = temp[j];
//    }





        //Foods
        idFood = findViewById(R.id.txtFood);
        adapterItemsFood = new ArrayAdapter<String>(this,R.layout.list_items, temp);
        idFood.setAdapter(adapterItemsFood);
        idFood.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                foodName = parent.getItemAtPosition(position).toString();
            }
        });

    }

    public void okFood(View view){
        current_food = foodsMap.get(foodName);
        TextView unit = (TextView)findViewById(R.id.tv_unit);
        unit.setText(current_food.unit);
    }

    public void submitClick(View view) {
        EditText ed_amount = (EditText) findViewById(R.id.ed_amount);
        int amount = Integer.parseInt(ed_amount.getText().toString().trim());
        double totalCalories = amount*Double.parseDouble(current_food.calories);

        TextView addMsg = (TextView)findViewById(R.id.calories);
        if (amount!=1){
            addMsg.setText(""+ amount + " " + current_food.name+ "  were added");
        }else{
            addMsg.setText(""+ amount + " " + current_food.name+ "  was added");
        }


//        TextView calories = (TextView)findViewById(R.id.calories);
//        calories.setText(""+totalCalories+ "calories in " + amount + " " + current_food.name);
        referenceClient.child(clientID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                double leftCalories = Double.parseDouble(
                        snapshot.child("leftCaloriesPerDay").getValue().toString());
                double leftCalories_update = leftCalories - amount*Double.parseDouble(current_food.calories);
                TextView tv_leftCalories_update = (TextView)findViewById(R.id.leftCalories);
                tv_leftCalories_update.setText(""+totalCalories+ " calories in " + amount + " " +
                        current_food.name+"\n"+leftCalories_update+ " calories left fot today.");

                referenceClient.child(clientID).child("leftCaloriesPerDay").setValue(leftCalories_update)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (!task.isSuccessful()) {
                                    Toast.makeText(AddMealClient.this,
                                            "feild update leftCaloriesPerDay", Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }



    public void addOneMore(View view) {
        Intent intent = new Intent(AddMealClient.this, AddMealClient.class);
        startActivity(intent);
    }



    public void returnClick(View view) {
        Intent intent = new Intent(AddMealClient.this, ClientHomePage.class);
        startActivity(intent);
        finish();
    }



    public boolean notEmpty(String str){
        if(str == null){
            Toast.makeText(getApplicationContext(), "Please fill all the fields!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}