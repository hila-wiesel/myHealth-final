package com.example.myhealthnew;

public class Administrator extends User{

    public Administrator(String email, String password) {
        super(email, password);
    }
}